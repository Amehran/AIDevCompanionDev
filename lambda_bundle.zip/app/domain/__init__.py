"""
Domain package: Domain models, schemas, and business entities.
"""
