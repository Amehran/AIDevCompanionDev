"""Service layer package.

This package contains stateless or stateful service classes encapsulating
infrastructure concerns (rate limiting, job management, etc.).
"""
