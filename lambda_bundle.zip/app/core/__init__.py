"""
Core package: Configuration, exceptions, and core business logic.
"""
